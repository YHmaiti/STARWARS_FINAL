using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DroidA2 : MonoBehaviour
{
    public Transform player;
    public float speed = 0.2f;
    public float stop_distance;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (player != null) {
            Vector3 direction = (player.position - transform.position).normalized;
            transform.position += direction * speed * Time.deltaTime;

            if (Vector3.Distance(transform.position, player.position) < 3f)
            {
                Debug.Log("they are here");
                //transform.position = new Vector3(transform.position.x, transform.position.y, 2.0f);
            }
        }
    }
}
